#!/bin/sh
mkdir -p "/usr/local/bin"
install -g 0 -o 0 "/home/vagrant/.WebStorm10/system/tmp/launcher0" "/usr/local/bin/wstorm"