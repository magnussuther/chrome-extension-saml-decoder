library validate;

part "src/error/errors.dart";
part "src/model/validate.dart";