/// This library contains token types used by the html5 tokenizer.
library token;

export 'package:html/src/token.dart';
