Replace all

    unquote("rgba(#{      ->       rgba(

    unquote("rgb(#{       ->       (

    })")                  ->       )

    },                    ->       ,

    )")                   ->       )

    palette-indigo        ->       palette-primary

    palette-pink          ->       palette-accent

in _variables.scss      ^

Palettes (14 colors)  50 - 900 + A100 - A700 possible
    palette-red
    palette-pink
    palette-purple
    palette-deep-purple
    palette-indigo
    palette-blue
    palette-light-blue
    palette-cyan
    palette-teal
    palette-green 
    palette-light-green
    palette-lime
    palette-yellow
    palette-amber
    palette-orange
    palette-deep-orange
       
Palettes (10 colors) 50 - 900 possible
    palette-brown
    palette-grey
    palette-blue-grey
    