// Copyright (c) 2013, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

// TODO(jmesserly): remove this script after a deprecation period.
if (typeof console == "object" && typeof console.warn == "function") {
  console.warn('<script src="packages/browser/interop.js"> is no longer ' +
      'needed for dart:js. See http://pub.dartlang.org/packages/browser.');
}
