library ds.core;

import 'dart:collection';
import 'dart:async';

part 'dsabstract.dart';
part 'dsiterable.dart';
part 'dsnode.dart';
part 'dslist.dart';
part 'dstree.dart';
part 'dsgraph.dart';
