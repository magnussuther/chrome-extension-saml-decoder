/// This library contains extra APIs that aren't in the DOM, but are useful
/// when interacting with the parse tree.
///
/// **DEPRECATED**. This package has been renamed `html`.
@Deprecated('Use the "html" package instead.')
library dom_parsing;

export 'package:html/dom_parsing.dart';
