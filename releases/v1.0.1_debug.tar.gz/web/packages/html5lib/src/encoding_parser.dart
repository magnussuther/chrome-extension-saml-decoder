library encoding_parser;

export 'package:html/src/encoding_parser.dart';
