/// Decodes bytes using the correct name. See [decodeBytes].
library char_encodings;

export 'package:html/src/char_encodings.dart';
