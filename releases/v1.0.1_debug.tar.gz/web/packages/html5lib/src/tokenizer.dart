library tokenizer;

export 'package:html/src/tokenizer.dart';
