// TODO(jmesserly): remove this once we have a subclassable growable list
// in our libraries.

/// A [List] proxy that you can subclass.
library list_proxy;

export 'package:html/src/list_proxy.dart';
